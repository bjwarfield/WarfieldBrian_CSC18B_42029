//Create an abstract class -> absSort
public abstract class absSort {
	//array variable
	protected int[] array;
	protected abstract void fillArray(int n);
}
